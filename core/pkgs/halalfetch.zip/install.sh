#!/bin/sh

set -e

echo $PWD
echo $MAKE_FLAGS

curl -O https://github.com/UzbekLinux/halalfetch/raw/refs/heads/main/halalfetch

cp halalfetch /usr/bin/halalfetch
chmod +x /usr/bin/halalfetch
