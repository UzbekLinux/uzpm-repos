#!/bin/sh
set -e

echo "$PWD"
echo "$MAKE_FLAGS"
echo "Привет, как дела"

curl -L -o halalfetch https://raw.githubusercontent.com/UzbekLinux/halalfetch/main/halalfetch

if [ ! -s halalfetch ]; then
    echo "Downloaded file is empty! Aborting."
    exit 1
fi

sudo cp halalfetch /usr/bin/halalfetch
sudo chmod +x /usr/bin/halalfetch
