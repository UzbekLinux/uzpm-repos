#!/bin/sh
set -e

DEST="${UZPM_DEST_DIR:-/}"

mkdir -p "$DEST"

mkdir -p $DEST/bin
mkdir -p $DEST/lib
mkdir -p $DEST/lib64
mkdir -p $DEST/sbin
mkdir -p $DEST/etc
mkdir -p $DEST/var
mkdir -p $DEST/usr

cat > $DEST/etc/shells << "EOF"
# Begin /etc/shells

/bin/sh
/bin/ash

# End /etc/shells
EOF

cat > $DEST/etc/resolv.conf << "EOF"
# Begin /etc/resolv.conf

nameserver 1.1.1.1
nameserver 8.8.8.8

# End /etc/resolv.conf
EOF

