#!/bin/sh
set -e

git clone --depth 1 https://github.com/torvalds/linux.git
cd linux

cp ../.config .config 
make olddefconfig
make $MAKE_FLAGS

mkdir -p "$UZPM_DEST_DIR"
mkdir -p "$UZPM_DEST_DIR/boot"

make INSTALL_MOD_PATH="$UZPM_DEST_DIR" modules_install
cp arch/x86/boot/bzImage "$UZPM_DEST_DIR/boot/"
