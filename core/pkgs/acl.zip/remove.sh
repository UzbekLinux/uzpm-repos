#!/bin/sh
set -e

DEST="${UZPM_DEST_DIR:-/}"
MTREE="$DEST/var/lib/uzpm/acl.mtree"

[ -f "$MTREE" ] || {
    echo "MTREE not found, nothing to remove"
    exit 1
}

sed 's|^\./||' "$MTREE" \
| awk '{print $1}' \
| grep -v '/$' \
| while read -r file; do
    rm -f "$DEST/$file"
done

sed 's|^\./||' "$MTREE" \
| awk '{print $1}' \
| grep '/$' \
| sort -r \
| while read -r dir; do
    rmdir --ignore-fail-on-non-empty "$DEST/$dir" 2>/dev/null || true
done
