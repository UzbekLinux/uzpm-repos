#!/bin/sh
set -e

CONFIGURE_PREFIX=""
if [ -n "$UZPM_DEST_DIR" ]; then
    CONFIGURE_PREFIX="--prefix=$UZPM_DEST_DIR"
    mkdir -p "$UZPM_DEST_DIR"
fi

curl -O https://ftp.gnu.org/gnu/binutils/binutils-2.45.tar.xz
tar -xpf binutils-2.45.tar.xz
cd binutils-2.45

../configure $CONFIGURE_PREFIX \
             --disable-nls       \
             --enable-gprofng=no \
             --disable-werror    \
             --enable-new-dtags  \
             --enable-default-hash-style=gnu

make $MAKE_FLAGS
make install
