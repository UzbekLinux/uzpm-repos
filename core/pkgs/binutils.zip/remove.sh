#!/bin/sh
set -e

echo "pashol naxxuy"
